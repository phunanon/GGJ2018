#ifndef HPP_ENTITY_INCLUDE
#define HPP_ENTITY_INCLUDE

#include "config.hpp"
#include "sound.hpp"
#include "map.hpp"

#define E_VILLAGER 0
#define E_ZOMBIE   1

class Entity;
class Projectile;

Entity* prot; //Protagonist

const uint8_t ENTITY_W = 32, ENTITY_H = 64;

enum StepDir {
    dir_away,
    dir_toward
};

std::vector<Entity*> entity = std::vector<Entity*>();
std::vector<Projectile*> projectile = std::vector<Projectile*>();

class Entity {
  public:
    uint8_t type = 255; // 0 Villager, 1 Zombie
    uint16_t index_in_array;
    bool is_dead = false;

    float pos_X = 0, pos_Y = 0; // Entity position
    uint16_t targ_X = 0, targ_Y = 0; //Target position
    float rot = 0; // As degrees
    uint8_t frame = 0;
    bool had_moved = true;
    float opacity = 1;

    uint64_t targetted_at = 0; //Last time this Entity was targetted
    uint64_t prev_hurt = 0; //Last time this entity was hurt

    float health_score = MAX_HEALTH;
    float max_health = MAX_HEALTH;
    float speed = NORMAL_SPEED;
    float power_score = ATTACK_DAMAGE;
    uint16_t kill_count = 0;

    Entity (uint8_t, float, float);
    Entity (); //For dummy entity

    void think (bool);
    void moveTowards (uint16_t, uint16_t);
    bool tryDir (float, float);
    void move ();
    void harm (Entity*, uint8_t);
    void heal (float);
    void animate ();
    void shoot (Entity*);
    void shootDir ();

  private:
      void loiter ();
      void attack (Entity*);
      void lashOut ();
      void step (StepDir, float, float, float);
      Entity* target = NULL;
      uint8_t attack_timeout = 0;
      uint64_t last_lashout = 0;
      float animate_clock = 0;
      float sound_pitch;
};

class Projectile {
  public:
    float pos_X, pos_Y;
    float vel_X, vel_Y;
    bool had_hit = false;
    bool was_successful = false;
    float opacity = 1;
    Entity* shooter;

    void move();
    Projectile(float, float, float, Entity*);
    ~Projectile();

};

bool enemyIsHere (Entity* here, uint16_t expected_x, uint16_t expected_y);

uint16_t findEntity (uint8_t type, uint16_t mid_X, uint16_t mid_Y, uint8_t radius);

#endif
