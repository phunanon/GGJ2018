#include "config.hpp"
#include <cmath>

const uint16_t mm_size = WINDOW_W / 8;
const uint16_t mm_diag_width = sqrt(pow(mm_size, 2) + pow(mm_size, 2));
