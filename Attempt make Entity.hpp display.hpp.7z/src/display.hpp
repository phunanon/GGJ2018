#ifndef HPP_DISPLAY_INCLUDE
#define HPP_DISPLAY_INCLUDE

#include <SFML/Graphics.hpp> //For SFML graphics
#include "config.hpp"
#include "math.hpp"
#include "map.hpp"
#include "Entity.hpp"


const uint8_t TILE_SCALE = 32;
const uint8_t TILE_W = 64, TILE_H = 32;
const uint8_t SPRITE_W = 64, SPRITE_H = 64;

//Display tiles
sf::Text txt_float;
sf::Text txt_HUD;
sf::Sprite biomeTile;
sf::Sprite spriteTile;
sf::Sprite entityTile;
sf::Sprite villagerTile;
sf::Sprite zombieTile;
sf::RectangleShape healthBar;
sf::CircleShape projectileTile (2);
//Minimap stuff
const uint32_t mm_len = MAP_A * 4;
sf::Texture mm_tex;
sf::RectangleShape minimap (sf::Vector2f(MAP_W, MAP_H));

float sky_darkness = 0;
const uint16_t daynight_cycle = 2000;

float daynight_colour (uint32_t game_time, uint16_t x, uint16_t y);

void getBiomeTex (uint16_t x, uint16_t y, uint8_t &biome_code, uint16_t &tex_X, uint16_t &tex_Y);
void getSpriteTex (uint8_t sprite_code, uint16_t x, uint16_t y, uint16_t &tex_X, uint16_t &tex_Y);

void getVillagerTex (Entity* e, uint16_t &tex_X, uint16_t &tex_Y);
void getZombieTex (Entity* e, uint16_t &tex_X, uint16_t &tex_Y);


void drawBiome (uint32_t game_time, sf::RenderWindow &window, float day_l, uint16_t x, uint16_t y, float draw_X, float draw_Y);

void drawSprite (uint32_t game_time, sf::RenderWindow &window, float day_l, uint16_t x, uint16_t y, float draw_X, float draw_Y);

void doISOMETRIC (uint32_t game_time, sf::RenderWindow &window, void (*drawer)(uint32_t, sf::RenderWindow&, float, uint16_t, uint16_t, float, float));

void drawEntities (uint32_t game_time, sf::RenderWindow &window);

void drawProjectiles (uint32_t game_time, sf::RenderWindow &window);

void doDISPLAY (uint32_t game_time, sf::RenderWindow &window, bool is_lazy = false);

#endif
