# Infection: a game made for Global Game Jam 2018
## Prerequisites:

`apt install libsfml-dev make`

## Installation:

`git clone https://github.com/danielshare/GGJ2018.git`

`cd GGJ2018`

`make`

`./GGJ2018`
